- `cd client` and run command `npm install`.
  After the packages are installed successfully, run the command `npm start` to start the app.
- server: you can use XAMPP, and use the `database_script_export.sql` file in the `database` folder to import the database to PHPMyAdmin. Then you have to change your API URL in the `api.js` file in `client/src/API` and reconfigure some things in the `config.php` file in `server/database/config.php`
