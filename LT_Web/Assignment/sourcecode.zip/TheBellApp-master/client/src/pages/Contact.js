import ContactPage from "../components/ContactPage";
function Contact() {
  return (
    <div className="contact-page">
      <ContactPage />
    </div>
  );
}

export default Contact;
