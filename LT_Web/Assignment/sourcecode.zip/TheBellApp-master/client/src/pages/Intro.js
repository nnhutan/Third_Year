import IntroPage from "../components/IntroPage";
function Intro() {
  return (
    <div className="intro-page">
      <IntroPage />
    </div>
  );
}

export default Intro;
