const API = "http://localhost/myself/assignment/server/API/";

export default API;
