
<?
print "The size of FILE__Determining_File_Size.php is. ";
print filesize( "FILE__Determining_File_Size.php" );
?>