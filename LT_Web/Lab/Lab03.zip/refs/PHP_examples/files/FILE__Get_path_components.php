<?php
$full_name = '/usr/local/php/php.ini';
$base = basename($full_name);  // $base is "php.ini"
$dir  = dirname($full_name);   // $dir is "/usr/local/php"
echo $base.'<br />'.$dir;
?>