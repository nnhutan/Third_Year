<?
$car = "1234567890";
$yr = substr($car, 0, 4);
print $yr;
?>