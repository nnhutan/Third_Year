<?php
   $input = "I just can't get <<enough>> of PHP!";
   echo htmlspecialchars($input);
?>

