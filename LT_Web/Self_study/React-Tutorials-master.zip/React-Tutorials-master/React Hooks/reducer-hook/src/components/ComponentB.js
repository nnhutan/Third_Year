import React from 'react'
import ComponentD from './ComponentD'

function ComponentB() {
	return (
		<div>
			Component B<ComponentD />
		</div>
	)
}

export default ComponentB
