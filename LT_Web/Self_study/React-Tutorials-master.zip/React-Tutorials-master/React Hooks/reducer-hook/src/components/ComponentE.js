import React from 'react'
import ComponentF from './ComponentF'

function ComponentE() {
	return (
		<div>
			Component E<ComponentF />
		</div>
	)
}

export default ComponentE
