import React from 'react'
import ComponentE from './ComponentE'

function ComponentC() {
	return <ComponentE />
}

export default ComponentC
