from PyQt5 import QtCore, QtWidgets, uic
import sys
import time
# ------------------------------------
from PIL import Image

import socket
import threading
import sys
import traceback
import os
from PyQt5 import QtGui

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMessageBox

from RtpPacket import RtpPacket

CACHE_FILE_NAME = "cache-"
CACHE_FILE_EXT = ".jpg"


class Client(QtWidgets.QMainWindow):
    INIT = 0
    READY = 1
    PLAYING = 2
    state = INIT

    SETUP = 0
    PLAY = 1
    PAUSE = 2
    TEARDOWN = 3
    DESCRIBE = 4

    videoLen = 500  # Số lượng frame của video
    videoTotalTime = 32

    totalDatatrans = 0  # tổng bytes đã truyền
    totalVideoDataRecd = 0
    totalPlayedTime = 0  # Tổng thời gian đã chạy
    oldTimestamp = 0
    lossCounter = 0
    glb_curFrame = 0

    # describeData = ""
    display_update = QtCore.pyqtSignal()

    def __init__(self):
        super(Client, self).__init__()
        uic.loadUi('client.ui', self)
        app.aboutToQuit.connect(self.handler)
        # self.infoText.setText("abc")
        # Khởi tạo các giá trị (lấu từ file Client.py gốc)

        self.serverAddr = str(self.serverAddrLine.text())
        # self.serverAddr = '192.168.1.9'
        self.serverPort = int(str(self.serverPortLine.text()))
        self.rtpPort = int(str(self.rtpPortLine.text()))
        self.fileName = str(self.fileNameLine.text())

        self.rtspSeq = 0
        self.sessionId = 0
        self.requestSent = -1
        self.teardownAcked = 0
        # Nếu đặt dòng này ở đây sẽ gây lỗi timeout
        # self.connectToServer()

        self.frameNbr = 0
        self.rtpSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Kết nối các button tới các handle function
        self.setupButton.clicked.connect(self.setupMovie)
        self.playButton.clicked.connect(self.playMovie)
        self.pauseButton.clicked.connect(self.pauseMovie)
        self.teardownButton.clicked.connect(self.exitClient)
        self.describeButton.clicked.connect(self.describeMovie)

        self.display_update.connect(self.guiUpdate)  # ADDED
        self.show()

    # def printButtonPressed(self):
    #     # This is executed when the button is pressed
    #     print('Input text:' + self.input.text())

    def setupMovie(self):
        """Setup button handler."""
        self.serverAddr = self.serverAddrLine.text()
        self.serverPort = int(str(self.serverPortLine.text()))
        self.rtpPort = int(str(self.rtpPortLine.text()))
        self.fileName = str(self.fileNameLine.text())

        if self.serverAddr == 'auto-detect':
            self.serverAddr = socket.gethostbyname(socket.gethostname())

        self.serverAddrLine.setText(str(self.serverAddr))
        self.connectToServer()
        if self.state == self.INIT:
            self.sendRtspRequest(self.SETUP)

        # Tính thời gian đã play
        self.totalPlayedTime = 0
        self.statusBar().showMessage("Connected!")

    def exitClient(self):
        """Teardown button handler."""
        self.sendRtspRequest(self.TEARDOWN)
        # Delete the cache image from video
        cachelist = os.listdir()
        for item in cachelist:
            if item.endswith(".jpg"):
                os.remove(item)

        # Dọn dẹp và reset toàn bộ :
        self.videoLabel.setPixmap(QtGui.QPixmap("imgplaceholder.png"))
        self.state = self.INIT

        self.rtspSeq = 0
        self.sessionId = 0
        self.requestSent = -1
        self.teardownAcked = 0

        self.frameNbr = 0

        self.totalDatatrans = 0  # tổng bytes đã truyền
        self.totalVideoDataRecd = 0
        self.totalPlayedTime = 0  # Tổng thời gian đã chạy
        self.oldTimestamp = 0
        self.lossCounter = 0
        self.glb_curFrame = 0

        # Thiết đặt lại GUI:
        self.horizontalSlider.setValue(0)
        self.infoLabel.setText("------ click DESCRIBE ------")
        self.totalDataTransLabel.setText("0 bytes")
        self.dataRateLabel.setText("0 bytes/s")
        self.totalLossLabel.setText("0 frame")
        self.lossRateLabel.setText("0 frame/s")
        self.totalTimeLabel.setText("--")
        self.remainingTimeLabel.setText("--")
        # sys.exit(0)

    def pauseMovie(self):
        """Pause button handler."""
        if self.state == self.PLAYING:
            self.sendRtspRequest(self.PAUSE)

    def playMovie(self):
        """Play button handler."""

        if self.state == self.INIT:
            self.setupMovie()
            time.sleep(0.5)

        if self.state == self.READY:
            # Create a new thread to listen for RTP packets
            threading.Thread(target=self.listenRtp).start()
            self.playEvent = threading.Event()
            self.playEvent.clear()
            self.sendRtspRequest(self.PLAY)

            # Tính thời gian đã play
            self.oldTimestamp = time.time()

    def describeMovie(self):
        self.sendRtspRequest(self.DESCRIBE)

    def listenRtp(self):
        """Listen for RTP packets."""
        while True:
            try:
                data = self.rtpSocket.recv(20480)
                # data = self.rtpSocket.recv(3000)
                if data:
                    # Tính tổng data đã truyền: (theo byte)
                    self.totalDatatrans += len(data)

                    # Tính tổng thời gian đã play: (theo giây)
                    timeStamp = time.time()
                    duration = timeStamp - self.oldTimestamp
                    self.oldTimestamp = timeStamp
                    self.totalPlayedTime += duration

                    rtpPacket = RtpPacket()
                    rtpPacket.decode(data)

                    currFrameNbr = rtpPacket.seqNum()

                    # Tính số frame loss
                    if self.frameNbr + 1 != currFrameNbr:
                        self.lossCounter += 1

                     # self.currFrame = currFrameNbr
                    self.glb_curFrame = currFrameNbr

               # print("Current Seq Num: " + str(currFrameNbr))

                    if currFrameNbr > self.frameNbr:  # Discard the late packet
                        self.frameNbr = currFrameNbr

                    self.updateMovie(self.writeFrame(
                        rtpPacket.getPayload()))

                self.display_update.emit()  # ADDED

            except:
                print("Connection Error, no reply received from server!")
                if self.frameNbr >= 500:
                    self.statusBar().showMessage("Reached end of video file!")
                # print('-'*60)
                # traceback.print_exc(file=sys.stdout)
                # print('-'*60)

                # Khi exception này xảy ra thì tức là video đã hết
                # ta đóng kết nối và dừng listening
                if self.teardownAcked == 1:
                    self.rtpSocket.shutdown(socket.SHUT_RDWR)
                    self.rtpSocket.close()
                    break

                break

    def writeFrame(self, data):
        """Write the received frame to a temp image file. Return the image file."""
        cachename = CACHE_FILE_NAME + str(self.sessionId) + CACHE_FILE_EXT
        file = open(cachename, "wb")
        file.write(data)
        file.close()
        # try:
        # self.totalVideoDataRecd += os.path.getsize(cachename)
        # self.totalVideoDataRecd += len(data)
        # except:
        #     print('-'*60)
        #     traceback.print_exc(file=sys.stdout)
        #     print('-'*60)

        return cachename

    def updateMovie(self, imageFile):
        """Update the image file as video frame in the GUI."""
        # self.totalVideoDataRecd += sys.getsizeof(imageFile) sai
        # str(round(self.totalDatatrans/(self.totalPlayedTime), 2))+"byte/frame")

        self.videoLabel.setPixmap(QPixmap(imageFile))

    def connectToServer(self):
        """Connect to the Server. Start a new RTSP/TCP session."""
        self.rtspSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.rtspSocket.connect((self.serverAddr, self.serverPort))
        except:
            # tkMessageBox.showwarning('Connection Failed', 'Connection to \'%s\' failed.' %self.serverAddr)
            print('connect to server failed')

    def sendRtspRequest(self, requestCode):
        """Send RTSP request to the server."""
        # -------------
        # TO COMPLETE
        # -------------

        # Setup request
        if requestCode == self.SETUP and self.state == self.INIT:
            threading.Thread(target=self.recvRtspReply).start()
            # Update RTSP sequence number.
            # ...
            self.rtspSeq = 1

            # Write the RTSP request to be sent.
            # request = ...
            request = "SETUP " + str(self.fileName) + " RTSP/1.0\nCSeq: " + str(
                self.rtspSeq) + "\nTransport: RTP/UDP; client_port= " + str(self.rtpPort)
            self.rtspSocket.send(request.encode("utf-8"))
            # Keep track of the sent request.
            # self.requestSent = ...
            self.requestSent = self.SETUP

        # Play request
        elif requestCode == self.PLAY and self.state == self.READY:
            # Update RTSP sequence number.
            # ...
            self.rtspSeq += 1

            # Write the RTSP request to be sent.
            # request = ...
            request = "PLAY " + str(self.fileName) + " RTSP/1.0\nCSeq: " + \
                str(self.rtspSeq) + "\nSession: " + str(self.sessionId)
            self.rtspSocket.send(request.encode("utf-8"))
            # Keep track of the sent request.
            # self.requestSent = ...
            self.requestSent = self.PLAY
        # Pause request
        elif requestCode == self.PAUSE and self.state == self.PLAYING:
            # Update RTSP sequence number.
            # ...
            self.rtspSeq += 1

            # Write the RTSP request to be sent.
            # request = ...
            request = "PAUSE " + str(self.fileName) + " RTSP/1.0\nCSeq: " + \
                str(self.rtspSeq) + "\nSession: " + str(self.sessionId)
            self.rtspSocket.send(request.encode("utf-8"))
            # Keep track of the sent request.
            # self.requestSent = ...
            self.requestSent = self.PAUSE
        # Teardown request
        elif requestCode == self.TEARDOWN and not self.state == self.INIT:
            # Update RTSP sequence number.
            # ...
            self.rtspSeq += 1
            # Write the RTSP request to be sent.
            # request = ...
            request = "TEARDOWN " + str(self.fileName) + " RTSP/1.0\nCSeq: " + str(
                self.rtspSeq) + "\nSession: " + str(self.sessionId)
            self.rtspSocket.send(request.encode("utf-8"))
            # Keep track of the sent request.
            # self.requestSent = ...
            self.requestSent = self.TEARDOWN

        elif requestCode == self.DESCRIBE:
            self.rtspSeq = self.rtspSeq + 1
            request = "DESCRIBE " + str(self.fileName) + " RTSP/1.0\nCSeq: " + str(
                self.rtspSeq) + "\nSesssion: " + str(self.sessionId)
            self.rtspSocket.send(request.encode("utf-8"))
            self.requestSent = self.DESCRIBE
        else:
            return

        # Send the RTSP request using rtspSocket.
        # ...

        print('\nClient sent:\n' + request)

    def recvRtspReply(self):
        """Receive RTSP reply from the server."""
        while True:
            reply = self.rtspSocket.recv(1024)

            if reply:
                self.parseRtspReply(reply.decode("utf-8"))

            # Close the RTSP socket upon requesting Teardown
            if self.requestSent == self.TEARDOWN:
                self.rtspSocket.shutdown(socket.SHUT_RDWR)
                self.rtspSocket.close()
                break

    def parseRtspReply(self, data):
        """Parse the RTSP reply from the server."""
        print("-"*40 + "\nClient received:\n" + data)
        lines = data.split('\n')
        seqNum = int(lines[1].split(' ')[1])

        # Process only if the server reply's sequence number is the same as the request's
        if seqNum == self.rtspSeq:
            session = int(lines[2].split(' ')[1])
            # New RTSP session ID
            if self.sessionId == 0:
                self.sessionId = session

            # Process only if the session ID is the same
            if self.sessionId == session:
                if int(lines[0].split(' ')[1]) == 200:
                    if self.requestSent == self.SETUP:
                        # -------------
                        # TO COMPLETE
                        # -------------
                        # Update RTSP state.
                        # self.state = ...
                        self.state = self.READY

                        # Open RTP port.
                        self.openRtpPort()
                    elif self.requestSent == self.PLAY:
                        # self.state = ...
                        self.state = self.PLAYING
                    elif self.requestSent == self.PAUSE:
                        # self.state = ...
                        self.state = self.READY
                        # The play thread exits. A new thread is created on resume.
                        self.playEvent.set()
                    elif self.requestSent == self.TEARDOWN:
                        # self.state = ...
                        self.state = self.INIT
                        # Flag the teardownAcked to close the socket.
                        self.teardownAcked = 1
                    elif self.requestSent == self.DESCRIBE:
                        self.infoLabel.setText(data)
                        # self.infoText.setText("Hreee")
                        # Client.describeData = data
                        # self.setDescribe()
                        # print(data)

    def openRtpPort(self):
        """Open RTP socket binded to a specified port."""
        # -------------
        # TO COMPLETE
        # -------------
        # Create a new datagram socket to receive RTP packets from the server
        # self.rtpSocket = ...

        # Set the timeout value of the socket to 0.5sec
        self.rtpSocket.settimeout(0.5)
        # Set the timeout value of the socket to 0.5sec
        # ...

        try:
            # Bind the socket to the address using the RTP port given by the client user
            # ...
            self.rtpSocket.bind((self.serverAddr, self.rtpPort))
        except:
            # tkMessageBox.showwarning(
            #     'Unable to Bind', 'Unable to bind PORT=%d' % self.rtpPort)
            print("Unable to Bind port")

    def handler(self):
        """Handler on explicitly closing the GUI window."""
        if self.state == self.PLAYING:
            self.pauseMovie()

        self.sendRtspRequest(self.TEARDOWN)

        cachelist = os.listdir()
        for item in cachelist:
            if item.endswith(".jpg"):
                os.remove(item)

        sys.exit(0)

    def guiUpdate(self):
        self.totalLossLabel.setText(
            str(self.lossCounter)+" frame")
        self.lossRateLabel.setText(
            str(self.lossCounter/self.totalPlayedTime)+" frame/s")
        # Cập nhật giao diện totalDatatrans
        self.totalDataTransLabel.setText(
            str(self.totalDatatrans)+" bytes")

        # Cập nhật giao diện Totaltimeplayed:

        self.totalTimeLabel.setText(
            str(round(self.totalPlayedTime//60)) + ":" + str(round(self.totalPlayedTime % 60)))

        remaining = self.videoTotalTime-self.totalPlayedTime

        self.remainingTimeLabel.setText(
            str(round(remaining//60)) + ":" + str(round(remaining % 60)))

        if self.videoLen-self.glb_curFrame <= 1:
            self.totalTimeLabel.setText("0:"+str(self.videoTotalTime))
            self.remainingTimeLabel.setText("0:0")

        # Cập nhật thanh slider:
        seekPos = round(self.glb_curFrame*300/self.videoLen)
        self.horizontalSlider.setValue(seekPos)

        # Cập nhật Datarate: totalVideoDataRecd
        self.dataRateLabel.setText(
            str(round(self.totalDatatrans/(self.totalPlayedTime+1), 2))+"byte/s")

        # cập nhật status bar()
        self.statusBar().showMessage("#Frame= "+str(self.glb_curFrame))


if __name__ == "__main__":
    try:
        app = QtWidgets.QApplication(sys.argv)
        window = Client()

        app.exec_()
    except:
        print("error")
